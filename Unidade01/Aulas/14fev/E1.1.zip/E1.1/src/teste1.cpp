#include <iostream>
using namespace std;

int main() 
{
    cout << "Teste 1" << endl;
    return 0;
}